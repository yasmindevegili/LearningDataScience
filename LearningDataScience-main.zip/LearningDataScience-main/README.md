# Data-Science
Exercises of Data Science of the book "Data Science from Scratch, 2nd Edition"
#### Databases from https://www.kaggle.com/
